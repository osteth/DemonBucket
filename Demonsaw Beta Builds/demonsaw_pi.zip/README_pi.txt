    _                                               
    | |                                              
  __| | ___ _ __ ___   ___  _ __  ___  __ ___      __
 / _` |/ _ \ '_ ` _ \ / _ \| '_ \/ __|/ _` \ \ /\ / /
| (_| |  __/ | | | | | (_) | | | \__ \ (_| |\ V  V / 
 \__,_|\___|_| |_| |_|\___/|_| |_|___/\__,_| \_/\_/  

demonsaw 2.03
Copyright 2014-2015 Demonsaw LLC All Rights Reserved
Believe in the Right to Share
Eijah

https://www.demonsaw.com
https://twitter.com/demon_saw
eijah@demonsaw.com


[note]
I've tested demonsaw_router and demonsaw the Raspberry Pi 2 Model B (https://www.raspberrypi.org/products/raspberry-pi-2-model-b/) Raspbian Debian Wheezy (2015-05-05). Unfortunately, I wasn't able to build/ test on other hardware versions or software distros.

If you run into problems, please refer to the following help:

(1) Make sure that your software is up-to-date
apt-get update -y
apt-get upgrade -y
apt-get dist-upgrade -y
apt-get autoremove -y

(2) Make sure that you have the following additional libraries installed.
apt-get install mesa-common-dev libcr-dev libglu1-mesa-dev libegl1-mesa-dev -y
apt-get install libxcb1 libxcb1-dev libx11-xcb1 libx11-xcb-dev libxcb-keysyms1 libxcb-keysyms1-dev libxcb-image0 libxcb-image0-dev libxcb-shm0 libxcb-shm0-dev libxcb-icccm4 libxcb-icccm4-dev libxcb-sync0 libxcb-sync0-dev libxcb-render-util0 libxcb-render-util0-dev libxcb-xfixes0-dev libxrender-dev libxcb-shape0-dev libxcb-randr0-dev libxcb-glx0-dev -y

(3) Due to some ARM compatibility issues with C++ 11, I've had to build the Raspberry Pi version of demonsaw with gcc 4.9. To update to gcc 4.9, please do the following:
change wheezy to jessie on 1st line in /etc/apt/sources.list
apt-get update
apt-get install gcc-4.9 g++-4.9
change jessie to wheezy on 1st line in /etc/apt/sources.list
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-4.6 60 --slave /usr/bin/g++ g++ /usr/bin/g++-4.6
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-4.9 40 --slave /usr/bin/g++ g++ /usr/bin/g++-4.9
update-alternatives --config gcc and select gcc 4.9 as the primary compiler

NOTE: You might not need to set gcc as the default compiler, as the installation of the gcc 4.9 standard C++ libraries might be enough.


[questions]
-------------------------------------------------------------------------------
For questions, suggestions, or feedback please email me at eijah@demonsaw.com

Thanks for using demonsaw!

-Eijah
