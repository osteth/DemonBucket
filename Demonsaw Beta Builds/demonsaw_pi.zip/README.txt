    _                                               
    | |                                              
  __| | ___ _ __ ___   ___  _ __  ___  __ ___      __
 / _` |/ _ \ '_ ` _ \ / _ \| '_ \/ __|/ _` \ \ /\ / /
| (_| |  __/ | | | | | (_) | | | \__ \ (_| |\ V  V / 
 \__,_|\___|_| |_| |_|\___/|_| |_|___/\__,_| \_/\_/  

demonsaw 2.03
Copyright 2014-2015 Demonsaw LLC All Rights Reserved
Believe in the Right to Share
Eijah

https://www.demonsaw.com
https://twitter.com/demon_saw
eijah@demonsaw.com


[contents]
-------------------------------------------------------------------------------
readme.txt
demonsaw_router
demonsaw.xml
demonsaw_example.xml


[demonsaw.xml]
-------------------------------------------------------------------------------
XML config file used by demonsaw and demonsaw_router. Both use the same demonsaw.xml file. This means that you can use demonsaw to configure the XML through a graphical user interface, then run demonsaw_router. You could also modify demonsaw.xml by hand in your favorite text editor.  You can provide the absolute path of demonsaw.xml as a command-line parameter to both programs, e.g. demonsaw <path_to_demonsaw_xml> or demonsaw_router <path_to_demonsaw_xml>. 


[demonsaw_example.xml]
XML config file with client and router examples.


[demonsaw_router]
-------------------------------------------------------------------------------
Command-line Interface (Router only)

The command-line app is faster than the graphical interface, but also has fewer features.

To run:
 * Open a command-prompt
 * Navigate to the folder where you extracted the contents of the zip file
 * Run demonsaw first, add a router (File -> Add -> Router), and configure the router
 * This will create the demonsaw.xml file which can then be read by demonsaw_router (the command-line version)
 * Run demonsaw_router

How to use...
DEMONSAW command

  r    routers
  s    servers
  c    clients
  g    groups
  t    transfers
  h    help
  q    quit       

At the demonsaw command-prompt type 'r' to view the routers, 's' to view the servers, 'c' to view the clients, etc.


[questions]
-------------------------------------------------------------------------------
For questions, suggestions, or feedback please email me at eijah@demonsaw.com

Thanks for using demonsaw!

-Eijah
