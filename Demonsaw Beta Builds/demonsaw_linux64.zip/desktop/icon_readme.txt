    _                                               
    | |                                              
  __| | ___ _ __ ___   ___  _ __  ___  __ ___      __
 / _` |/ _ \ '_ ` _ \ / _ \| '_ \/ __|/ _` \ \ /\ / /
| (_| |  __/ | | | | | (_) | | | \__ \ (_| |\ V  V / 
 \__,_|\___|_| |_| |_|\___/|_| |_|___/\__,_| \_/\_/  

demonsaw 2.02
Copyright 2014-2015 Demonsaw LLC All Rights Reserved
Believe in the Right to Share
https://www.demonsaw.com
https://twitter.com/demon_saw
eijah@demonsaw.com


[icon]
-------------------------------------------------------------------------------
sudo cp demonsaw.desktop /usr/share/applications/
chmod 644 /usr/share/applications/demonsaw.desktop

Icon is under the Internet menu
