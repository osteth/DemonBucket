    _                                               
    | |                                              
  __| | ___ _ __ ___   ___  _ __  ___  __ ___      __
 / _` |/ _ \ '_ ` _ \ / _ \| '_ \/ __|/ _` \ \ /\ / /
| (_| |  __/ | | | | | (_) | | | \__ \ (_| |\ V  V / 
 \__,_|\___|_| |_| |_|\___/|_| |_|___/\__,_| \_/\_/  

demonsaw 2.4.0
Copyright 2014-2015 Demonsaw LLC All Rights Reserved
Believe in the Right to Share
Eijah

https://www.demonsaw.com
https://twitter.com/demon_saw
eijah@demonsaw.com


[contents]
-------------------------------------------------------------------------------
readme.txt
demonsaw
demonsaw_router
demonsaw.xml
demonsaw_example.xml
demonsaw.css.txt


[demonsaw.xml]
-------------------------------------------------------------------------------
XML config file used by demonsaw and demonsaw_router. Both use the same demonsaw.xml file. This means that you can use demonsaw to configure the XML through a graphical user interface, then run demonsaw_router. You could also modify demonsaw.xml by hand in your favorite text editor.  You can provide the absolute path of demonsaw.xml as a command-line parameter to both programs, e.g. demonsaw <path_to_demonsaw_xml> or demonsaw_router <path_to_demonsaw_xml>. 


[demonsaw_example.xml]
XML config file with client and router examples.


[demonsaw]
-------------------------------------------------------------------------------
Graphical User Interface (Client & Router)

To run:
* Double-click on demonsaw


[demonsaw_router]
-------------------------------------------------------------------------------
Command-line Interface (Router only)

The command-line app is faster than the graphical interface, but also has fewer features.

To run:
 * Open a command-prompt
 * Navigate to the folder where you extracted the contents of the zip file
 * Run demonsaw first, add a router (File -> Add -> Router), and configure the router
 * This will create the demonsaw.xml file which can then be read by demonsaw_router (the command-line version)
 * Run demonsaw_router

How to use...
DEMONSAW command

  r    routers
  s    servers
  c    clients
  g    groups
  t    transfers
  h    help
  q    quit       

At the demonsaw command-prompt type 'r' to view the routers, 's' to view the servers, 'c' to view the clients, etc.


[demonsaw.css.txt]
-------------------------------------------------------------------------------
The css file allows you to configure the graphical settings for demonsaw. To enable the CSS functionality, rename demonsaw.css.txt to demonsaw.css and make sure that demonsaw.css is located in the same folder as demonsaw. You can change the colors, layout, or anything else. Feel free to email me any alterations that you make and I'll include the new CSS files in future releases. For an overview of configuring css for Qt applications, take a look at http://doc.qt.digia.com/4.6/stylesheet-examples.html.


[linux]
I've tested demonsaw_router and demonsaw on Kali 1.1.0a (32/64 bit) and Ubuntu 14.04.2 (32/64 bit). Unfortunately, I wasn't able to test on other distros or versions. If you run into problems, please refer to the following help:


[kali 1.1.0a]
-------------------------------------------------------------------------------
Make sure the following prerequisites are installed.

sudo apt-get install mesa-common-dev libcr-dev libglu1-mesa-dev -y 

sudo apt-get install libxcb1 libxcb1-dev libx11-xcb1 libx11-xcb-dev libxcb-keysyms1 libxcb-keysyms1-dev libxcb-image0 libxcb-image0-dev libxcb-shm0 libxcb-shm0-dev libxcb-icccm4 libxcb-icccm4-dev libxcb-sync0 libxcb-sync0-dev libxcb-render-util0 libxcb-render-util0-dev libxcb-xfixes0-dev libxrender-dev libxcb-shape0-dev libxcb-randr0-dev libxcb-glx0-dev -y


[ubuntu 14.04.2]
-------------------------------------------------------------------------------
Make sure the following prerequisites are installed.

sudo apt-get install mesa-common-dev libcr-dev libglu1-mesa-dev -y 

sudo apt-get install libxcb1 libxcb1-dev libx11-xcb1 libx11-xcb-dev libxcb-keysyms1 libxcb-keysyms1-dev libxcb-image0 libxcb-image0-dev libxcb-shm0 libxcb-shm0-dev libxcb-icccm4 libxcb-icccm4-dev libxcb-sync1 libxcb-sync0-dev libxcb-render-util0 libxcb-render-util0-dev libxcb-xfixes0-dev libxrender-dev libxcb-shape0-dev libxcb-randr0-dev libxcb-glx0-dev -y

[symbolic links]
1) If you get the following error: "error while loading shared libraries: libxcb-sync.so.0: cannot open shared object file: No such file or directory"

To fix this....
locate libxcb-sync.so
	/usr/lib/x86_64-linux-gnu/libxcb-sync.so.1
	/usr/lib/x86_64-linux-gnu/libxcb-sync.so.1.0.0

Then create a symbolic link between your newer library and the old library name:
ln -s /usr/lib/x86_64-linux-gnu/libxcb-sync.so.1 /usr/lib/x86_64-linux-gnu/libxcb-sync.so.0

2) If you get the following error: "error while loading shared libraries: libudev.so.0: cannot open shared object file: No such file or directory"

To fix this....
sudo apt-get install libudev1

locate libudev.so
/lib/x86_64-linux-gnu/libudev.so.1
/lib/x86_64-linux-gnu/libudev.so.1.5.0

Then create a symbolic link between your newer library and the old library name:
ln -sf /lib/x86_64-linux-gnu/libudev.so.1 /usr/lib/x86_64-linux-gnu/libudev.so.0


[questions]
-------------------------------------------------------------------------------
For questions, suggestions, or feedback please email me at eijah@demonsaw.com

Thanks for using demonsaw!

-Eijah
